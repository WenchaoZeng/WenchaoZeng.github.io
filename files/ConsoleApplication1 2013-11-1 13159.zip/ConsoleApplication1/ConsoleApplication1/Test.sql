﻿create procedure Test(
    @a int,
    @b int
)
as
begin

select @a + @b

end