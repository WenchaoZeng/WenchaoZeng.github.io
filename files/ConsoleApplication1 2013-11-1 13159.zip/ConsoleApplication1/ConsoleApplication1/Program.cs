﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Runtime.Remoting;
using ConsoleApplication1.Model;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            DAOFactory factory = new DAOFactory();

            ITestDAO dao = factory.CreateDAO<ITestDAO>();

            try
            {
                int result = dao.Test(4, 6);
                Console.WriteLine("result: {0}", result);
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}: {1}", ex.GetType().Name, ex.Message);
            }

            long sid = dao.Insert(new TestEntity() { Field2 = "hello" });
            Console.WriteLine("Inserted sid: {0}", sid);

            TestEntity item = dao.GetSingle<TestEntity>(sid);
            Console.WriteLine("Item gotten: {0}", item.Field2);

            item.Field2 = "test";
            long sid2 = dao.Update(item);
            Console.WriteLine("updated: {0}", sid);

            long sid3 = dao.Delete(item);
            Console.WriteLine("updated: {0}", sid3);

            try
            {
                //long sid = dao.Insert(new TestEntity() { Field2 = "hello" });
                //Console.WriteLine("Inserted sid: {0}", sid);

                //TestEntity item = dao.GetSingle<TestEntity>(sid);
                //Console.WriteLine("Item gotten: {0}", item.Field2);

                //item.Field2 = "test";
                //long sid2 = dao.Update(item);
                //Console.WriteLine("updated: {0}", sid);

                //long sid3 = dao.Delete(item);
                //Console.WriteLine("updated: {0}", sid3);
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}: {1}", ex.GetType().Name, ex.Message);
            }

            try
            {
                dao.GetList(1, 2);
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}: {1}", ex.GetType().Name, ex.Message);
            }



            Console.ReadKey();
        }
    }
}
