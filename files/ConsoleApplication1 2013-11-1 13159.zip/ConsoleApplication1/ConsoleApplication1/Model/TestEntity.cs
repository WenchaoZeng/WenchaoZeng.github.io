﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace ConsoleApplication1
{
    public class TestEntity : BaseDAOEntity
    {
        public long SID { get; set; }
        public string Field2 { get; set; }

        public override SqlParameter[] PrepareSqlParameters()
        {
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("SID", this.SID);
            parameters[1] = new SqlParameter("Field2", this.Field2);
            return parameters;
        }

        public static string Insert
        {
            get
            {
                return "insert into [dbo].[TestTable]([Field2]) values(@Field2); select convert(bigint, @@Identity);";
            }
        }

        public static string Update
        {
            get
            {
                return "update [dbo].[TestTable] set [Field2] = @Field2 where [SID] = @SID; select @SID;";
            }
        }

        public static string GetSingle
        {
            get
            {
                return "select * from [dbo].[TestTable] where [SID] = @SID";
            }
        }

        public static string Delete
        {
            get
            {
                return "update [dbo].[TestTable] set [MarkForDelete] = 1 where [SID] = @SID; select @SID;";
            }
        }
    }
}
