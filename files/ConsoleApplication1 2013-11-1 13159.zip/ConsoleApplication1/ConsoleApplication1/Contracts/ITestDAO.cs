﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public interface ITestDAO : IBaseDAO
    {
        [StoredProcedureCall("Test")]
        int Test(int a, int b);

        [StoredProcedureCall("Test_GetList")]
        IEnumerable<TestEntity> GetList(int startIndex, int count);
    }
}
