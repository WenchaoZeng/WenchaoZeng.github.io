﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public interface IBaseDAO
    {
        [SqlCall(SqlName = "Insert")]
        long Insert<T>(T item) where T : BaseDAOEntity;

        [SqlCall(SqlName = "Update")]
        long Update<T>(T item) where T : BaseDAOEntity;

        [SqlCall(SqlName = "GetSingle")]
        T GetSingle<T>(long sid) where T : BaseDAOEntity;

        [SqlCall(SqlName = "Delete")]
        long Delete<T>(T item) where T : BaseDAOEntity;
    }
}
