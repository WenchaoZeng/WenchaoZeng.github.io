﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Reflection;

namespace ConsoleApplication1
{
    public class DAOProxy : IProxyInvocationHandler
    {
        protected string GetSql(SqlCallAttribute sqlCallAttribute, MethodInfo method, object[] parameters)
        {
            // If sql text is embed in SqlCallAttribute
            if (sqlCallAttribute.SqlText != null)
            {
                return sqlCallAttribute.SqlText;
            }

            PropertyInfo propertyInfo = null;

            if (propertyInfo == null)
            {
                propertyInfo = method.ReturnType.GetProperty(sqlCallAttribute.SqlName);
            }

            if (propertyInfo == null)
            {
                foreach (object obj in parameters)
                {
                    if (obj is BaseDAOEntity)
                    {
                        propertyInfo = obj.GetType().GetProperty(sqlCallAttribute.SqlName);
                    }
                }
            }

            return (string)propertyInfo.GetValue(null, null);
        }

        protected SqlParameter[] PrepareSqlParameters(string sqlName, MethodInfo method, object[] parameters)
        {
            if (parameters.Length > 0 && parameters[0] is BaseDAOEntity)
            {
                if (sqlName == "Delete")
                {
                    SqlParameter[] sqlParameters = new SqlParameter[1];
                    sqlParameters[0] = ((BaseDAOEntity)parameters[0]).PrepareSqlParameters()[0];
                    return sqlParameters;
                }
                else
                {
                    return ((BaseDAOEntity)parameters[0]).PrepareSqlParameters();
                }
            }
            else
            {
                ParameterInfo[] parameterInfos = method.GetParameters();
                SqlParameter[] sqlParameters = new SqlParameter[parameterInfos.Length];
                for (int index = 0; index < sqlParameters.Length; ++index)
                {
                    sqlParameters[index] = new SqlParameter(parameterInfos[index].Name, parameters[index]);
                }

                return sqlParameters;
            }
        }

        protected object ExecuteQuery(string cmdText, SqlParameter[] parameters, CommandType commandType, Type returnType)
        {
            using (SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=Test;Integrated Security=True"))
            using (SqlCommand cmd = new SqlCommand())
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            using (DataSet dataSet = new DataSet())
            {
                cmd.Connection = conn;
                cmd.CommandType = commandType;
                cmd.CommandText = cmdText;
                cmd.Parameters.AddRange(parameters);

                conn.Open();
                adapter.Fill(dataSet);

                return ReadResultFromDataTable(returnType, dataSet.Tables[0]);
            }
        }

        protected object ReadResultFromDataTable(Type returnType, DataTable dataTable)
        {
            // Base on return type, the result will be parsed differenctly, convert to a value type of convert to a list of customized entities.
            if (
                returnType == typeof(int) ||
                returnType == typeof(bool) ||
                returnType == typeof(byte) ||
                returnType == typeof(long) ||
                returnType == typeof(double) ||
                returnType == typeof(DateTime))
            {
                var result = dataTable.Rows[0][0];
                return result;
            }
            else if (typeof(BaseDAOEntity).IsAssignableFrom(returnType))
            {
                // For customized entities, an entity instant will be created and read from DataTable
            }
            else if (typeof(IEnumerable).IsAssignableFrom(returnType))
            {
                // For a list of entities, an entity list will be created and read from DataTable
            }

            return null;
        }

        public object Invoke(object proxy, MethodInfo method, object[] parameters)
        {
            object attribute = method.GetCustomAttributes(true)[0];

            if (attribute is SqlCallAttribute)
            {
                SqlCallAttribute sqlCallAttribute = ((SqlCallAttribute)attribute);
                string sqlText = GetSql(sqlCallAttribute, method, parameters);
                SqlParameter[] sqlParameters = PrepareSqlParameters(sqlCallAttribute.SqlName, method, parameters);
                return ExecuteQuery(sqlText, sqlParameters, CommandType.Text, method.ReturnType);
            }

            if (attribute is StoredProcedureCallAttribute)
            {
                StoredProcedureCallAttribute storedProcedureCallAttribute = (StoredProcedureCallAttribute)attribute;
                string procedureName = storedProcedureCallAttribute.Name;
                SqlParameter[] sqlParameters = PrepareSqlParameters(string.Empty, method, parameters);
                return ExecuteQuery(procedureName, sqlParameters, CommandType.StoredProcedure, method.ReturnType);
            }

            return null;
        }
    }
}
