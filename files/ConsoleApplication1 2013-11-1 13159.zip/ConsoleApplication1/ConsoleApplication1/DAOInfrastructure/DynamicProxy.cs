﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Remoting.Proxies;
using System.Runtime.Remoting.Messaging;
using System.Reflection;
using System.Collections;

namespace ConsoleApplication1
{
    public class DynamicProxy<T> : RealProxy
    {
        protected readonly IProxyInvocationHandler handler = null;

        public DynamicProxy(IProxyInvocationHandler handler)
            : base(typeof(T))
        {
            this.handler = handler;
        }

        public T Object
        {
            get
            {
                return (T)GetTransparentProxy();
            }
        }

        public override IMessage Invoke(IMessage msg)
        {
            object[] parameters = null;
            foreach (DictionaryEntry item in msg.Properties)
            {
                string key = item.Key.ToString();
                object value = item.Value;

                if (key == "__Args")
                {
                    parameters = (object[])value;
                }
            }

            var methodBaseProperty = msg.GetType().GetProperty("MethodBase");
            MethodInfo methodInfo = (MethodInfo)methodBaseProperty.GetValue(msg, null);

            object result = handler.Invoke(this.Object, methodInfo, parameters);

            return new ReturnMessage(result, null, 0, null, (IMethodCallMessage)msg);
        }
    }
}
