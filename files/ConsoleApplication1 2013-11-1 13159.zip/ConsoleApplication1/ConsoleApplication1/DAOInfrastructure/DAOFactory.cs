﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class DAOFactory
    {
        public T CreateDAO<T>()
        {
            return new DynamicProxy<T>(new DAOProxy()).Object;
        }
    }
}
