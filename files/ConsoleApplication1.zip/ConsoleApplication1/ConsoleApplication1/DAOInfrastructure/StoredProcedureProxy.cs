﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Collections;
using System.Reflection;

namespace ConsoleApplication1
{
    public class StoredProcedureProxy : DynamicProxy.IProxyInvocationHandler
    {
        public object Invoke(object proxy, System.Reflection.MethodInfo method, object[] parameters)
        {
            object[] attributes = method.GetCustomAttributes(typeof(StoredProcedureCallAttribute), true);
            StoredProcedureCallAttribute storedProcedureCallAttribute = (StoredProcedureCallAttribute)attributes[0];
            
            string procedureName = storedProcedureCallAttribute.Name;
            string[] parameterNames = storedProcedureCallAttribute.ParameterNames;
            if (parameterNames.Length <= 0)
            {
                ParameterInfo[] parameterInfos = method.GetParameters();
                parameterNames = new string[parameterInfos.Length];
                for (int index = 0; index < parameterInfos.Length; ++index)
                {
                    parameterNames[index] = parameterInfos[index].Name;
                }
            }

            Console.WriteLine(
                "Calling stored procedure {0}({1}) by parameters ({2})",
                procedureName,
                "@" + string.Join(", @", parameterNames),
                string.Join(", ", parameters));

            using (SqlConnection conn = new SqlConnection("Data Source=.;Initial Catalog=Test;Integrated Security=True"))
            using (SqlCommand cmd = new SqlCommand())
            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
            using (DataSet dataSet = new DataSet())
            {
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.CommandText = procedureName;
                for (int index = 0; index < parameters.Length; ++index)
                {
                    object value = parameters[index];
                    string name = parameterNames[index];

                    if (
                        value is int ||
                        value is bool ||
                        value is byte ||
                        value is long ||
                        value is double ||
                        value is DateTime)
                    {
                        // For value type, it will be directly added.
                        cmd.Parameters.AddWithValue(name, value);
                    }
                    else if (value is BaseDAOEntity)
                    {
                        // For customized entities, it will be converted into DataTable.
                    }
                    else if (value is IEnumerable)
                    {
                        // For a list of entities, it will be converted into DataTable.
                    }
                }

                conn.Open();

                adapter.Fill(dataSet);

                // Base on return type, the result will be parsed differenctly, convert to a value type of convert to a list of customized entities.
                if (
                    method.ReturnType == typeof(int) ||
                    method.ReturnType == typeof(bool) ||
                    method.ReturnType == typeof(byte) ||
                    method.ReturnType == typeof(long) ||
                    method.ReturnType == typeof(double) ||
                    method.ReturnType == typeof(DateTime))
                {
                    var result = dataSet.Tables[0].Rows[0][0];
                    return result;
                }
                else if (typeof(BaseDAOEntity).IsAssignableFrom(method.ReturnType))
                {
                    // For customized entities, an entity instant will be created and read from DataTable
                }
                else if (typeof(IEnumerable).IsAssignableFrom(method.ReturnType))
                {
                    // For a list of entities, an entity list will be created and read from DataTable
                }

                return null;
            }
        }
    }
}
