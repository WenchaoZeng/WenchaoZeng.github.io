﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class DAOFactory
    {
        public T CreateDAO<T>()
        {
            // http://www.codeproject.com/Articles/5511/Dynamic-Proxy-Creation-Using-C-Emit
            return (T)DynamicProxy.ProxyFactory.GetInstance().Create(new StoredProcedureProxy(), typeof(T), true);
        }

        // Implement by ReadProxy
        public T CreateDAO2<T>()
        {
            return new DynamicProxy2.DynamicProxy<T>(new StoredProcedureProxy()).Object;
        }
    }
}
