﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class StoredProcedureCallAttribute : Attribute
    {
        public readonly string Name;
        public readonly string[] ParameterNames;

        public StoredProcedureCallAttribute(string name, params string[] parameterNames)
        {
            this.Name = name;
            this.ParameterNames = parameterNames;
        }
    }
}
