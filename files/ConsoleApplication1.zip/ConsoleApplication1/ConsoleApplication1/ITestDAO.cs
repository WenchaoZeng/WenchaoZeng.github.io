﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public interface ITestDAO
    {
        [StoredProcedureCall("Test")]
        int Test(int a, int b);

        [StoredProcedureCall("Test", "a", "b")]
        int Test2(int a, int b);

        [StoredProcedureCall("Test_GetList")]
        IEnumerable<TestEntity> GetList(int startIndex, int count);

        [StoredProcedureCall("Test_Update")]
        void Update(TestEntity entity);
    }
}
