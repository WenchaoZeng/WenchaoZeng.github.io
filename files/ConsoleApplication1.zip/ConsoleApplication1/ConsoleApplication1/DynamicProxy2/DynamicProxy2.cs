﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Remoting.Proxies;
using System.Runtime.Remoting.Messaging;
using System.Reflection;
using System.Collections;

namespace ConsoleApplication1.DynamicProxy2
{
    public class DynamicProxy<T> : RealProxy
    {
        protected readonly DynamicProxy.IProxyInvocationHandler handler = null;

        public DynamicProxy(DynamicProxy.IProxyInvocationHandler handler)
            : base(typeof(T))
        {
            this.handler = handler;
        }

        public T Object
        {
            get
            {
                return (T)GetTransparentProxy();
            }
        }

        public override IMessage Invoke(IMessage msg)
        {
            Type type = typeof(T);
            MethodInfo methodInfo = null;
            object[] parameters = null;
            foreach (DictionaryEntry item in msg.Properties)
            {
                string key = item.Key.ToString();
                object value = item.Value;
                if (key == "__MethodName")
                {
                    string methodName = (string)value;
                    methodInfo = typeof(T).GetMethod(methodName);
                }
                else if (key == "__Args")
                {
                    parameters = (object[])value;
                }
            }

            handler.Invoke(this.Object, methodInfo, parameters);

            return new ReturnMessage(10, null, 0, null, (IMethodCallMessage)msg);
        }
    }
}
