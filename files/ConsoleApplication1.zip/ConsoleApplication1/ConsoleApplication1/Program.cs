﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Runtime.Remoting;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            DAOFactory factory = new DAOFactory();

            ITestDAO dao = factory.CreateDAO2<ITestDAO>();
            int result = dao.Test2(4, 6);
            Console.WriteLine("result: {0}", result);

            try
            {
                dao.GetList(1, 2);
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}: {1}", ex.GetType().Name, ex.Message);
            }

            try
            {
                TestEntity entity = new TestEntity() { SID = 2, Field1 = "test" };
                dao.Update(entity);
            }
            catch (Exception ex)
            {
                Console.WriteLine("{0}: {1}", ex.GetType().Name, ex.Message);
            }

            Console.ReadKey();
        }
    }
}
